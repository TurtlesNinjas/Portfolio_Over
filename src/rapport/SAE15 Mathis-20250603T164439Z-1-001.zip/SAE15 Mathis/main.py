import csv

file = open("Fichiers_de_donnees_conso_annuelles_V1.csv","r")
csvreader = csv.DictReader(file,delimiter=";")

nombre_apr= dict()
for row in csvreader:
  idaprt= row["ID logement"]
  if idaprt not in nombre_apr:
    nombre_apr[idaprt]= 0
  nombre_apr[idaprt]+= 1

table = '<table border=1>\n'
table += '<tr><th>Numéro de logement</th><th>Nombre d\'appareils</th></tr>\n'
for logement, nombre in nombre_apr.items():
    table += f'<tr><td>{logement}</td><td>{nombre}</td></tr>\n'
table+= "<link rel='stylesheet' href='style.css'>"
table += '</table>'

with open("table.html", "w") as file:
    file.write(table)